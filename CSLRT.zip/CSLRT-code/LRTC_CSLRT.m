function [X,OUT,PSNR,iter] = LRTC_CSLRT(M,omega,opts,M_true,X0)
%%% Solve the Low-Rank Tensor Completion (LRTC) based on CSLRT by PAM algorithm
%
% min_{X,Z,D,S,Q} ||Z||_*+lambda||S||_1, 
% s.t. P_Omega(X) = P_Omega(B), X = Z ��_3 D, X = S ��_3 Q
%      ||D(:,k)||_F = 1, ||Q(:,k)||_F = 1
% ---------------------------------------------
% Written by Li Ben-Zheng (lbz1604179601@126.com)
%
% References: 
%Ben-Zheng Li, Xi-Le Zhao, Jian-Li Wang, Yong Chen, Tai-Xiang Jiang and Jun Liu, 
%Tensor Completion Via Collaborative Sparse and Low-Rank Transforms,
%IEEE Transactions on Computational Imaging, vol. 7, pp. 1289-1303, 2021.

if ~exist('opts', 'var')
    opts = [];
end

if isfield(opts, 'tol');        tol         =  opts.tol;         end
if isfield(opts, 'max_iter');   max_iter    =  opts.max_iter;	 end
if isfield(opts, 'beta1');      beta1       =  opts.beta1;       end
if isfield(opts, 'beta2');      beta2       =  opts.beta2;       end
if isfield(opts, 'd');          d     	    =  opts.d;           end
if isfield(opts, 'q');          q     	    =  opts.q;           end
if isfield(opts, 'lambda');     lambda      =  opts.lambda;      end
if isfield(opts, 'rho1');       rho1        =  opts.rho1;        end
if isfield(opts, 'rho2');       rho2        =  opts.rho2;        end
if isfield(opts, 'DEBUG');      DEBUG   	=  opts.DEBUG;     	 end
if isfield(opts, 'D0');      	D0          =  opts.D0;          end
if isfield(opts, 'Q0');      	Q0          =  opts.Q0;          end
if isfield(opts, 'Z0');      	Z0          =  opts.Z0;         end
if isfield(opts, 'S0');      	S0          =  opts.S0;         end
%% initialization
Dim         = size(M);
X           = X0;
X(omega)    = M(omega);
Z           = Z0;
S           = S0;
D           = D0;
Q           = Q0;
PSNR = [];
SSIM = [];
for iter    = 1 : max_iter
    Xk	= X;
    Dk	= D;
    Qk  = Q;
    Zk	= Z;
    Sk  = S;
    X_mat  = Unfold(X,size(X),3);
    Zk_mat = Unfold(Zk,size(Z),3);
    Sk_mat = Unfold(Sk,size(S),3);

    %% update d_i and z_i
    DZ_new = 0;
    DZ_old = D * Zk_mat;
    for i  = 1:d
        DZ_old = DZ_old - D(:,i) * Zk_mat(i,:);
        X1bar        = X_mat - DZ_new - DZ_old;
        betad1kXbar = Fold(beta1 * D(:,i)' * X1bar,[Dim(1:2),1],3);
        z1ki        = Zk(:,:,i);
        p1ki         = beta1 * X1bar * z1ki(:)+ rho1 * Dk(:,i);
        if iter>5
            D(:,i)     = p1ki / norm(p1ki);
        else
            D(:,i) =  D(:,i);
        end
        temp1 = (1/(beta1 + rho1)).*(betad1kXbar + rho1 * z1ki);
        [Z(:,:,i)]    = prox_nuclear(temp1,1/(beta1 + rho1));
        zki_new = Z(:,:,i);
        DZ_new = DZ_new+ D(:,i)*zki_new(:)';        
    end
   %% update s_i and q_i
    QS_new = 0;
    QS_old = Q * Sk_mat;
    for i = 1:q
        QS_old = QS_old - Q(:,i) * Sk_mat(i,:);
        X2bar        = X_mat - QS_new - QS_old;
        betad2kXbar = Fold(beta2 * Q(:,i)' * X2bar,[Dim(1:2),1],3);
        ski        = Sk(:,:,i);
        p2ki         = beta2 * X2bar * ski(:)+ rho1 * Qk(:,i);
        if iter>5
            Q(:,i)     = p2ki/norm(p2ki);
        else
            Q(:,i) =  Q(:,i);
        end    
        temp2 = (1/(beta2 + rho1)).*( betad2kXbar + rho1 * ski);
        S(:,:,i)    = prox_l1(temp2,lambda/(beta2 + rho1));
        ski_new = S(:,:,i);
        QS_new = QS_new + Q(:,i) * ski_new(:)';        
    end
    %% update X
    DZ = Fold(D * Unfold(Z,size(Z),3),size(X),3);
    QS = Fold(Q * Unfold(S,size(S),3),size(X),3);
    if iter>10
    X = (beta1 * DZ  + beta2 * QS + rho2 * Xk )./ (beta1 + beta2 + rho2);
    end
    X(omega) = M(omega);
%% Check convergence
    chgX    = norm(Xk(:)-X(:))/norm(Xk(:));OUT.chgX(iter) = chgX;
      
    if iter == 15
        beta1 = beta1 * 1.5;
        beta2 = beta2 * 1.5;
    end
    
    if iter == 20
        beta1 = beta1 * 1.5;
        beta2 = beta2 * 1.5;
    end
    
    if iter == 25
        beta1 = beta1 * 1.5;
        beta2 = beta2 * 1.5;
    end
    
    if iter > 30
        beta1 = beta1 * 1.2;
        beta2 = beta2 * 1.2;
    end
        [psnr, ssim] = quality_my(M_true * 255,X * 255);
        PSNR = [PSNR,psnr];
        SSIM = [SSIM,ssim];

        if iter == 1 || mod(iter, 10) == 0
            fprintf('CSLRT: iter = %d PSNR=%f SSIM=%f resX=%f \n',iter, psnr,ssim,chgX);
        end

    if iter > 10
        if chgX < tol
            break;
        end
    end
end
OUT.Z = Z;
OUT.D = D;
OUT.X = X;
end

