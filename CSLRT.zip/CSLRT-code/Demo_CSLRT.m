%%% Solve the Low-Rank Tensor Completion (LRTC) based on CSLRT by PAM algorithm
% ---------------------------------------------
% min_{X,Z,D,S,Q} ||Z||_*+lambda||S||_1, 
% s.t. X_\Omega = O_\Omega, X = Z ��_3 D, X = S �� Q
%      ||D(:,k)||_F = 1, ||Q(:,k)||_F = 1
% ---------------------------------------------
% Reference:
% Ben-Zheng Li, Xi-Le Zhao, Jian-Li Wang, Yong Chen, Tai-Xiang Jiang, Jun
% Liu, "Tensor Completion Via Collaborative Sparse and Low-Rank Transforms",
% IEEE Transactions on Computational Imaging, vol. 7, pp. 1289-1303, 2021
% ---------------------------------------------
% Updated by 
% Li Ben-Zheng 
% E-mail: lbz1604179601@126.com; lbz1604179601@gmail.com
% Date: 01/09/2022
%% =================================================================
clc;
clear;
close all;
%% Load initial data
load('Balloons.mat');
X = Omsi_1;
%% Sampling with random position
sample_ratio = [0.1];
Y_tensorT   = X;
[n1,n2,n3]  = size(Y_tensorT);
Ndim        = ndims(Y_tensorT);
Nway        = size(Y_tensorT);
rand('state',0);
Omega       = find(rand(prod(Nway),1)<sample_ratio);
Ind         = zeros(size(Y_tensorT));
Ind(Omega)  = 1;
Y_tensor0   = zeros(Nway);
Y_tensor0(Omega) = Y_tensorT(Omega);
%% Interpolation 
A = Y_tensor0;
B = padarray(A,[20,20,20],'symmetric','both');
C = padarray(Ind,[20,20,20],'symmetric','both');
%a0 = interpolate2(B,C);
a1 = interpolate(shiftdim(B,1),shiftdim(C,1));
a1(a1<0) = 0;
a1(a1>1) = 1;
a1 = a1(21:end-20,21:end-20,21:end-20);
a1 = shiftdim(a1,2);
a1(Omega) = Y_tensorT(Omega);

a2 = interpolate(shiftdim(B,2),shiftdim(C,2));
a2(a2<0) = 0;
a2(a2>1) = 1;
a2 = a2(21:end-20,21:end-20,21:end-20);
a2 = shiftdim(a2,1);
a2(Omega) = Y_tensorT(Omega);

a3(Omega) = Y_tensorT(Omega);
a = 0.5*a1+0.5*a2;
X0 = a;%rand(size(Y_tensor0));
X0(Omega) = Y_tensorT(Omega);

%% Parameters
kkk = 0;
opts = [];
lambda = 0.001;
beta1 = 10;
beta2 = 0.001;
d = 62;%[n3 2*n3 3*n3], [n3 n3+20 n3+40]
q = 31;%[n3 2*n3]
kkk = kkk+1;
X_m = Unfold(X0,size(X0),3);
Ind_m = Unfold(Ind,size(Ind),1);
Ind1   = sum(Ind_m,1);
[~,D_omega] = sort(Ind1(:),'descend');
D0 = X_m(:,D_omega(1:d));
D0 = D0./sqrt(sum(D0.^2,1));
Q0 = X_m(:,D_omega(1:q));
Q0 = Q0./sqrt(sum(Q0.^2,1));
rand('state',0);
Z0 = rand(n1,n2,d)./d;
S0 = rand(n1,n2,q)./q;
opts.lambda     = lambda;
opts.d          = d;
opts.q          = q;
% rho1 = 10;
% rho2 = 0.01;
opts.rho1       = 10;
opts.rho2       = 0.01;
opts.tol        = 1e-4;
opts.beta1      = beta1;
opts.beta2      = beta2;
opts.DEBUG      = 0;
opts.max_iter   = 300;
opts.X0 = X;
opts.Z0 = Z0;
opts.S0 = S0;
opts.D0 = D0;
opts.Q0 = Q0;
tStart = tic;
%% Performing CSLRT
    [Re_tensor,OUT,psnr,iterations] = LRTC_CSLRT(Y_tensor0,Omega,opts,Y_tensorT,X0);
%% Results
    time= toc(tStart);
    iters = iterations;
    [MPSNRALL, SSIMALL] = quality_my(Y_tensorT*255, Re_tensor*255);
    fprintf(' %5.3f    %5.4f      %3d     %.1f | lambda = %.3f beta1 = %.3f beta2 = %.3f d = %.0f q = %.0f  \n',...
        MPSNRALL, SSIMALL,iters,time,opts.lambda,opts.beta1,opts.beta2,opts.d,opts.q);
